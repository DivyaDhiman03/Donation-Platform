const Receiver = () => {
  return (
    <div className="w-full h-screen flex items-center justify-center bg-pink-900">
    <h1 className="text-3xl font-bold">Welcome to the Receiver Page</h1>
  </div>
  )
}

export default Receiver