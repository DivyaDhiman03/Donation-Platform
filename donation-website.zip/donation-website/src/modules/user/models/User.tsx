type User = {
    username:string;
    password:string;
}
export default User;