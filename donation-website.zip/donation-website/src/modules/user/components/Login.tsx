
import { useForm } from "react-hook-form";
import { AiOutlineClose } from "react-icons/ai";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate } from "react-router-dom";
import { signInWithGoogle } from "@/modules/auth/services/firebase.ts";
import { FcGoogle } from "react-icons/fc";
import { UserLoginSchema, userLoginSchema } from "../schema/login-user-schema.ts";

const Login = () => {
    const navigate = useNavigate();
    
    const { register, handleSubmit, formState: { errors } } = useForm<UserLoginSchema>({
        resolver: zodResolver(userLoginSchema),
    });
    
    const doLogin = (userLoggingIn: UserLoginSchema) => {
        console.log("User is trying to log in:", userLoggingIn);

        const storedUser = localStorage.getItem("user");

        if (!storedUser) {
            alert("No account found. Please sign up first.");
            return;
        }

        const parsedUser: UserLoginSchema = JSON.parse(storedUser);

        if (parsedUser.email === userLoggingIn.email && parsedUser.password === userLoggingIn.password) {
            localStorage.setItem("isAuthenticated", "true");
            alert("Login successful!");
            navigate("/category");
            window.location.reload();
        } else {
            alert("Invalid email or password. Please try again.");
        }
    };
    
    return (
        <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50 backdrop-blur-md">
            <div className="relative w-[50%]  flex flex-col justify-center items-center bg-[#f6f8f9] shadow-lg rounded-lg p-6">
                <button className="absolute top-4 right-4" onClick={() => navigate("/")}> 
                    <AiOutlineClose size={28} className="stroke-[34]" />
                </button>
                <h1 className="font-bold text-4xl p-4 mt-8">SIGN IN</h1>
                <form onSubmit={handleSubmit(doLogin)}>
                    <div className="flex flex-col">
                        <label className="mb-2 mt-2 text-gray-500">Email :</label>
                        <input className="p-2 shadow w-[25vw] border rounded" {...register("email")} type="text" placeholder="Type Email Here" />
                        {errors.email && <p className="text-red-500">{errors.email.message}</p>}
                    </div>
                    <div className="flex flex-col">
                        <label className="mb-2 mt-2 text-gray-500">Password :</label>
                        <input className="p-2 shadow w-[25vw] border rounded" {...register("password")} type="password" placeholder="Type Password Here" />
                        {errors.password && <p className="text-red-500">{errors.password.message}</p>}
                    </div>
                    <button type="submit" className="bg-[#fca311] text-white font-bold px-6 py-2 rounded-md shadow-md mt-4 w-[25vw] mb-2">
                        SIGN IN
                    </button>
                </form>
                <div className="flex flex-col mt-2">
                    <h1 className="text-center pb-2 text-gray-500">Or</h1>
                    <button className="flex items-center w-[25vw] space-x-2 border border-gray-300 px-4 py-2 rounded hover:bg-gray-100 transition duration-150 mb-4" onClick={signInWithGoogle}>
                        <FcGoogle size={24} />
                        <span>Sign in with Google</span>
                    </button>
                </div>
                <div className="flex w-[25vw] mb-4 justify-center">
                    <h1 className="text-gray-500 mr-2">Don't have an account?</h1>
                    <span className="text-[#fca311] cursor-pointer font-bold hover:underline" onClick={() => navigate("/signup")}>Sign Up</span>
                </div>
            </div>
        </div>
    );
};

export default Login;
