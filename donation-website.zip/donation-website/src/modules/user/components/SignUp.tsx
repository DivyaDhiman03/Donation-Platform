/* eslint-disable @typescript-eslint/no-unused-vars */
import { useForm } from "react-hook-form";
import { userSchema, UserSchema } from "../schema/user-schema";
import { AiOutlineClose } from "react-icons/ai";
import { zodResolver } from "@hookform/resolvers/zod";
import { useNavigate } from "react-router-dom";

const SignUp = () => {
  // Hook for programmatic routing
  const navigate = useNavigate();

  // Zod validation with React Hook Form  
  const { register, handleSubmit, formState: { errors } } = useForm<UserSchema>({
    resolver: zodResolver(userSchema),
  });

  const doSubmit = (user: UserSchema) => {
    console.log("User signed up:", user);
    // Saving user data in localStorage (excluding confirmPassword)
    const { confirmPassword, ...userData } = user;
    localStorage.setItem("user", JSON.stringify(userData));

    alert("Account created successfully! You can now log in.");
    navigate("/login"); // Redirect to login page after successful signup
  };

  return (
    <div className="fixed inset-0 flex justify-center items-center bg-black bg-opacity-50 backdrop-blur-md">
      <div className="relative w-[50%] flex flex-col justify-center items-center bg-[#f6f8f9] shadow-lg rounded-lg p-6">
        
        {/* Close Button */}
        <button className="absolute top-4 right-4" onClick={() => navigate("/")}>
          <AiOutlineClose size={28} className="stroke-[34]" />
        </button>
        <h1 className="font-bold text-4xl p-4 mt-8">SIGN UP</h1>

        {/* Validation part start */}
        <form onSubmit={handleSubmit(doSubmit)}>
          
          <div className="flex flex-col">
            <label htmlFor="email" className="mb-2 mt-2 text-gray-500">Email : </label>
            <input
              className="p-2 shadow w-[25vw]"
              {...register("email")}
              type="text"
              placeholder="Type Email Here"
            />
            {errors.email && <p style={{ color: "red" }}>{errors.email.message}</p>}
          </div>

          <div className="flex flex-col">
            <label htmlFor="password" className="mb-2 mt-2 text-gray-500">Password : </label>
            <input
              className="p-2 shadow w-[25vw]"
              {...register("password")}
              type="password"
              placeholder="Type Password Here"
            />
            {errors.password && <p style={{ color: "red" }}>{errors.password.message}</p>}
          </div>

          <div className="flex flex-col">
            <label htmlFor="confirmPassword" className="mb-2 mt-2 text-gray-500">Confirm Password : </label>
            <input
              className="p-2 shadow w-[25vw]"
              {...register("confirmPassword")}
              type="password"
              placeholder="Confirm Password Here"
            />
            {errors.confirmPassword && <p style={{ color: "red" }}>{errors.confirmPassword.message}</p>}
          </div>

          {/* Display error if any field has an issue */}
          {(errors.email || errors.password || errors.confirmPassword) && (
            <p className="text-red-500 mt-2">Please enter your credentials</p>
          )}

          <div>
            <button
              type="submit"
              className="bg-[#fca311] text-white font-bold px-6 py-2 rounded-[4px] shadow-md mt-4 w-[25vw] mb-2"
            >
              Sign Up
            </button>
          </div>
        </form>
        {/* Validation part end */}

        {/* Sign Up Link */}
        <div className="flex w-[25vw] mb-4 justify-center">
          <h1 className="text-gray-500 mr-2">Already have an account?</h1>
          <span
            className="text-[#fca311] cursor-pointer font-bold hover:underline"
            onClick={() => navigate("/login")}
          >
            Login
          </span>
        </div>
      </div>
    </div>
  );
};

export default SignUp;
