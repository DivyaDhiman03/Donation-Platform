const About = () => {
  return (
    <div className="text-white">About</div>
  )
}

export default About