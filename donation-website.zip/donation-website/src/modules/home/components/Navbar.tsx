
import { NavLink, useNavigate } from "react-router-dom";
import { useState, useEffect } from "react";

const Navbar = () => {

  const navigate = useNavigate();
  const [isAuthenticated, setIsAuthenticated] = useState<boolean>(false);


  useEffect(() => {
    const authStatus = localStorage.getItem("isAuthenticated") === "true";
    setIsAuthenticated(authStatus);
  }, []);

 

  const handleLogout = () => {
    localStorage.removeItem("isAuthenticated");
    alert("Logged out successfully!");
    navigate("/");
    window.location.reload();
  };

  return (
<nav className=" fixed w-[100%] bg-gradient-to-r from-[#1a1a1a] to-[#666666] p-3 shadow-[0_8px_16px_rgba(0,0,0,0.2)] z-50">





      <div className="container mx-auto flex justify-between items-center w-[90%]  flex-wrap">
      <div className="flex items-center gap-2">
              {/* <img src="https://cdn-icons-png.flaticon.com/128/14263/14263513.png" alt="" className="h-10" /> */}
              <h3 className="text-xl font-bold text-white">Give<span className='text-[#ffbf69]'>&</span>Gather</h3>
            </div>

        <div className="flex items-center gap-x-8 ">
          {isAuthenticated ? (
            <>
              {/* <NavLink to="/category" className="text-white font-bold hover:text-[#fca311]">Category</NavLink> */}
              {/* <NavLink to="/about" className="text-white font-bold hover:text-[#fca311]">ABOUT</NavLink> */}
              {/* <NavLink to="/services" className="text-white font-bold hover:text-[#fca311]">SERVICES</NavLink> */}
              {/* <NavLink to="/contact" className="text-white font-bold hover:text-[#fca311]">CONTACT</NavLink> */}
              <button 
                className="bg-[#ffbf69] px-6 py-3  rounded-[4px] hover: transition-colors text-l text-white font-bold"
                onClick={handleLogout}
              >
                LOGOUT
              </button>
            </>
          ) : (
            <>
              <NavLink to="/" className="text-white font-bold hover:text-[#fca311]">HOME</NavLink>
              <NavLink to="/about" className="text-white font-bold hover:text-[#fca311]">ABOUT</NavLink>
              <NavLink to="/services" className="text-white font-bold hover:text-[#fca311]">SERVICES</NavLink>
              <NavLink to="/contact" className="text-white font-bold hover:text-[#fca311]">CONTACT</NavLink>
              <button 
                className="bg-[#ffbf69]  px-6 py-3 rounded-[4px] hover: transition-colors text-l text-white font-bold"
                onClick={() => navigate("/login")}
              >
                START DONATING
              </button>
            </>
          )}
        </div>
      </div>
    </nav>
  );
};

export default Navbar;