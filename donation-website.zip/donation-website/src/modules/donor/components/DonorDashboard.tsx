import { useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { CheckCircle, Camera, Plus, Calendar, MapPin } from "lucide-react";

const DonorDashboard = () => {
  const [showSuccess, setShowSuccess] = useState(false);
  const [foodTitle, setFoodTitle] = useState("");
  const [description, setDescription] = useState("");
  const [vegQty, setVegQty] = useState(5);
  const [nonVegQty, setNonVegQty] = useState(5);
  const [activeTab, setActiveTab] = useState("myPost");


  const handleSubmit = () => {
    setShowSuccess(true);
  };

  return (
    <div className="w-full min-h-screen bg-gray-100 p-6 ">
      {/* Donor Header */}
      <div className="bg-white shadow-md rounded-lg p-4 mb-4 mt-[5%]">
        <h1 className="text-xl font-semibold">Hi, Divya</h1>
        <p className="text-gray-500">
          You are a <span className="font-bold text-green-600">Super Donor</span>
        </p>
        <div className="mt-2 flex space-x-4">
          <div className="text-center">
            <p className="font-semibold">500</p>
            <p className="text-gray-500 text-sm">Donations</p>
          </div>
          <div className="text-center">
            <p className="font-semibold">500</p>
            <p className="text-gray-500 text-sm">Feedback Received</p>
          </div>
          <div className="text-center">
            <p className="font-semibold">1000</p>
            <p className="text-gray-500 text-sm">Points Earned</p>
          </div>
        </div>
      </div>
   {/* Tabs: My Post & Receivers Requests */}
   <div className="bg-white shadow-md rounded-lg p-4 mb-4">
        <div className="flex border-b">
          <button
            className={`flex-1 py-2 text-center font-semibold ${
              activeTab === "myPost" ? "border-b-2 border-black" : "text-gray-500"
            }`}
            onClick={() => setActiveTab("myPost")}
          >
            My Post
          </button>
          <button
            className={`flex-1 py-2 text-center font-semibold ${
              activeTab === "requests" ? "border-b-2 border-black" : "text-gray-500"
            }`}
            onClick={() => setActiveTab("requests")}
          >
            Receivers Requests
          </button>
        </div>

        {/* My Post Content */}
        {activeTab === "myPost" && (
          <div className="p-4">
            <p className="text-gray-500">Nothing till now</p>
            <p className="text-gray-500">Do you have some items to donate?</p>
            <Button className="w-full mt-2 bg-black text-white">
              + Create Donation Post
            </Button>
          </div>
        )}

        {/* Receivers Requests Content */}
        {activeTab === "requests" && (
          <div className="p-4">
            <h2 className="text-lg font-semibold">Requests for Items</h2>
            <div className="mt-2">
              <Card className="mb-2">
                <CardContent className="p-3">
                  <h3 className="font-semibold">NGO Name #1</h3>
                  <p className="text-gray-500">Request: 20 Plates (Veg)</p>
                  <p className="text-gray-500">Location: 12A, Vasant Kunj, New Delhi</p>
                  <Button className="mt-2 bg-blue-500 text-white w-full">Donate Now</Button>
                </CardContent>
              </Card>
              <Card className="mb-2">
                <CardContent className="p-3">
                  <h3 className="font-semibold">NGO Name #2</h3>
                  <p className="text-gray-500">Request: 15 Plates (Non-Veg)</p>
                  <p className="text-gray-500">Location: 10B, Connaught Place, New Delhi</p>
                  <Button className="mt-2 bg-blue-500 text-white w-full">Donate Now</Button>
                </CardContent>
              </Card>
            </div>
          </div>
        )}
      </div>

      {/* Donation History */}
      <Card className="mb-4">
        <CardContent className="p-4">
          <h2 className="text-lg font-semibold flex justify-between">
            Donation History <span className="text-blue-500 text-sm">View All</span>
          </h2>
          <p className="text-gray-500">Jackets</p>
          <p className="text-gray-500">1| Denim</p>
          <p className="text-green-600 font-semibold">Posted just now</p>
        </CardContent>
      </Card>

      {/* NGOs Near You */}
      <Card className="mb-4">
        <CardContent className="p-4">
          <h2 className="text-lg font-semibold">NGOs Near You</h2>
          <div className="flex items-center mt-2">
            <MapPin className="w-5 h-5 text-gray-500 mr-2" />
            <p className="text-gray-500">2.5km away</p>
          </div>
        </CardContent>
      </Card>

      {/* Donation Form */}
      <Card className="mb-4">
        <CardContent className="p-4">
          <h2 className="text-lg font-semibold">Listing Type: Donation</h2>
          <input
            type="text"
            placeholder="Add food title"
            value={foodTitle}
            onChange={(e) => setFoodTitle(e.target.value)}
            className="w-full border rounded p-2 my-2"
          />
          <textarea
            placeholder="Description"
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            className="w-full border rounded p-2 my-2"
          />
          <select className="w-full border rounded p-2 my-2">
            <option>Cooked Food - Veg & Non-Veg</option>
            <option>Cooked Food - Veg Only</option>
            <option>Cooked Food - Non-Veg Only</option>
          </select>

          {/* Quantity Selection */}
          <div className="my-2">
            <label className="flex items-center space-x-2">
              <input type="checkbox" checked readOnly />
              <span>Veg</span>
              <button onClick={() => setVegQty(Math.max(1, vegQty - 1))}>-</button>
              <span>{vegQty}</span>
              <button onClick={() => setVegQty(vegQty + 1)}>+</button>
            </label>
          </div>
          <div className="my-2">
            <label className="flex items-center space-x-2">
              <input type="checkbox" checked readOnly />
              <span>Non-Veg</span>
              <button onClick={() => setNonVegQty(Math.max(1, nonVegQty - 1))}>-</button>
              <span>{nonVegQty}</span>
              <button onClick={() => setNonVegQty(nonVegQty + 1)}>+</button>
            </label>
          </div>

          {/* Upload Images */}
          <div className="flex space-x-2 my-2">
            <Button variant="outline">
              <Camera className="w-5 h-5" />
            </Button>
            <Button variant="outline">
              <Camera className="w-5 h-5" />
            </Button>
            <Button variant="outline">
              <Plus className="w-5 h-5" />
            </Button>
          </div>

          {/* Expiration Date */}
          <div className="flex items-center space-x-2 my-2">
            <Calendar className="w-5 h-5 text-gray-500" />
            <input type="date" className="border p-2 rounded w-full" />
          </div>

          {/* Submit Button */}
          <Button className="w-full bg-black text-white mt-4" onClick={handleSubmit}>
            Submit Donation
          </Button>
        </CardContent>
      </Card>

      {/* Success Message */}
      {showSuccess && (
        <Card className="mt-4">
          <CardContent className="p-4 flex flex-col items-center">
            <CheckCircle className="w-12 h-12 text-green-600 mb-2" />
            <h2 className="text-lg font-semibold text-green-600">Awesome!</h2>
            <p className="text-gray-500">Your donation request posted successfully</p>
            <Button className="mt-2 bg-blue-500 text-white">Back to Home</Button>
          </CardContent>
        </Card>
      )}
    </div>
  );
};

export default DonorDashboard;
