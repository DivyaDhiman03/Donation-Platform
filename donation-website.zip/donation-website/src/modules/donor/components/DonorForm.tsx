import { useState } from "react";
import { useForm } from "react-hook-form";
import { useNavigate } from "react-router-dom";

type FormData = {
  name: string;
  mobile: string;
  email: string;
  address: string;
  pinCode: string;
  city: string;
};

const DonorForm = () => {
  const [showSuccess, setShowSuccess] = useState(false);
  const navigate = useNavigate();
  const {
    register,
    handleSubmit,
    formState: { errors },
  } = useForm<FormData>();

  const onSubmit = (data: FormData) => {
    console.log("Form Data:", data);

    // Save form data to localStorage
    localStorage.setItem("donorData", JSON.stringify(data));

    setShowSuccess(true);

    // Wait for 1 second and then navigate
    setTimeout(() => {
      navigate("/donordashboard");
    }, 1000);
  };

  return (
    <div className="flex flex-col md:flex-row items-center justify-center min-h-screen bg-white py-10 px-5 w-[100%]">
      <div className="w-[90%] flex ">
        {/* Image Section */}
        <div className="md:block w-[50%] mt-[5%] m-4">
          <img src="/src/assets/donate.jpg" alt="Donor" className="w-[100%] h-[80vh] mr-5" />
        </div>

        {/* Form Section */}
        <div className="bg-white w-[50%] p-6 rounded-lg shadow-md w-full md:w-1/2 md:mr-8 m-4 mt-[5%]">
          <h2 className="text-xl font-semibold mb-4">Donor Details</h2>
          <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
            <input type="text" {...register("name", { required: "Full Name is required" })} placeholder="Full Name" className="w-full border rounded-md p-2" />
            {errors.name && <p className="text-red-500 text-sm">{errors.name.message}</p>}

            <input type="tel" {...register("mobile", { required: "Mobile Number is required", pattern: { value: /^[0-9]{10}$/, message: "Invalid mobile number" } })} placeholder="Mobile Number" className="w-full border rounded-md p-2" />
            {errors.mobile && <p className="text-red-500 text-sm">{errors.mobile.message}</p>}

            <input type="email" {...register("email", { required: "Email is required", pattern: { value: /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/, message: "Invalid email format" } })} placeholder="Email ID" className="w-full border rounded-md p-2" />
            {errors.email && <p className="text-red-500 text-sm">{errors.email.message}</p>}

            <input type="text" {...register("address", { required: "Address is required" })} placeholder="Address" className="w-full border rounded-md p-2" />
            {errors.address && <p className="text-red-500 text-sm">{errors.address.message}</p>}

            <input type="text" {...register("pinCode", { required: "Pin Code is required", pattern: { value: /^[0-9]{6}$/, message: "Invalid Pin Code" } })} placeholder="Pin Code" className="w-full border rounded-md p-2" />
            {errors.pinCode && <p className="text-red-500 text-sm">{errors.pinCode.message}</p>}

            <input type="text" {...register("city", { required: "City is required" })} placeholder="City" className="w-full border rounded-md p-2" />
            {errors.city && <p className="text-red-500 text-sm">{errors.city.message}</p>}

            <button type="submit" className="bg-[#212121] w-full text-white py-2 rounded-md">
              Submit
            </button>
          </form>
        </div>
      </div>

      {/* Success Modal */}
      {showSuccess && (
        <div className="fixed top-0 left-0 w-full h-full flex items-center justify-center bg-black bg-opacity-50">
          <div className="bg-white p-6 rounded-lg shadow-md w-full max-w-sm text-center">
            <span className="text-green-500 text-6xl">✔️</span>
            <h2 className="text-xl font-semibold mt-4">Congrats Donor!</h2>
            <p className="text-gray-700">You are all set to go</p>
            <button onClick={() => setShowSuccess(false)} className="mt-4 w-full bg-blue-600 text-white py-2 rounded-md">
              Continue
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default DonorForm;
