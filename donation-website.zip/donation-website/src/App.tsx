
// import LoginPage from "./modules/user/pages/LoginPage"

import HomePage from "./modules/home/pages/HomePage"

const App = () => {
  return (
    <>
    {/* <LoginPage/> */}
    <HomePage/>
    </>
  )
}

export default App


